/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package inventariopoo2;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Main {

    public static void main(String[] args) throws IOException {
        /*
        * Se instancia el MainFrame desde la clase Main
        */
        
        Servidor servidor = new Servidor();

        MainFrame mainFrame = new MainFrame();
        mainFrame.setTitle("Empresas Tren Maya MX - Reportes/Folios");
        mainFrame.setVisible(true);
       
        servidor.inicioservidor(5000);
        //servidor.finservidor();
    } 
} 
