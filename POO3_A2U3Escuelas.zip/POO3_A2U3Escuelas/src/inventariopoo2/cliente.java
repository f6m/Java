/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package inventariopoo2;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;

/**
 *
 * @author lunas
 */
class Cliente {
    
private String ipv4 = "127.0.0.1";
// establece los canales de entrada y de salida a disposicion de las clases de usuario
public InputStream entrada; //Stream de bytes de entrada
public OutputStream salida; //Stream de bytes de salida

//para los canales de salida
private PrintWriter s;
private BufferedReader e;

// El socket cliente
public Socket cliente;
public Socket clienteSocket;


//para iniciar la conexion con el servidor
public void iniciaConexion(int port) throws IOException {
        clienteSocket = new Socket(ipv4, port);
        s = new PrintWriter(clienteSocket.getOutputStream(), true);
        e = new BufferedReader(new InputStreamReader(clienteSocket.getInputStream()));
    }

public void detieneConexion() throws IOException {
        s.flush();
        e.close();
        s.close();
        clienteSocket.close();
        System.out.println("Conexion cerrada: "+clienteSocket);
    }

public String enviaCadena(String str) throws IOException {
        s.println(str);
        String resp = e.readLine();
        return resp;
    }

public String enviaImagen(DataInputStream ima) throws IOException {
        s.println(ima);
        String resp = e.readLine();
        return resp;
    }
public String getFolio() throws IOException {
        String resp = e.readLine();
        return resp;
    }
//constructor con dos parametros host, puerto
/*public Cliente (String host, int port) {
try {
cliente = new Socket(host, port);
System.out.println ("Datos del socket:  " + cliente);
entrada = cliente.getInputStream();
salida = cliente.getOutputStream();
} catch (IOException e) {
System.out.println("IOExc : " + e);
}
}*/
}  

