/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package inventariopoo2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;
import java.util.concurrent.Executors;

/**
 *
 * @author lunas
 */
// Esta clase es la que implementa el socket del servidor (ServerSocket)
class Servidor {

private ServerSocket server;
private Socket socket;
private ServerSocket serverSocket;
private Socket clienteSocket;


//para entrada/salidas del servidor
private PrintWriter s;
private BufferedReader e;

public Integer folio=0;
public InputStream entradastream;
public OutputStream salidastream;

public void inicioservidor(int port) throws IOException  {
        serverSocket = new ServerSocket(port);
        
        var pool = Executors.newFixedThreadPool(20);
        
        //clienteSocket = serverSocket.accept();
        while(true){
        pool.execute(new Capitalizer(serverSocket.accept()));
        //Informar de la accion de inicio del servidor
        //System.out.println ("Servidor Java Activo! \n");
        //System.out.println(""+serverSocket+"\n");
        
        //s = new PrintWriter(clienteSocket.getOutputStream(), true);
        //e = new BufferedReader(new InputStreamReader(clienteSocket.getInputStream()));
        //String empresa = e.readLine();
        //folio++;  
        //s.println(empresa+folio);
        }
      }

//parar los sockets
public void finservidor() throws IOException {
        e.close();
        s.close();
        //clienteSocket.close();
        //serverSocket.close();
    }


//implementa los servicios mediante hilos para cada cliente, 
private static class Capitalizer implements Runnable {
        private Socket socket;
        static int f;
        
        Capitalizer(Socket socket) {
            this.socket = socket;
        }

        @Override
        public void run() {
            System.out.println("Connected: " + socket);
            try {
                //var in = new Scanner(socket.getInputStream());
                //var out = new PrintWriter(socket.getOutputStream(), true);
                //while (in.hasNextLine()) {
                //    out.println(in.nextLine().toUpperCase());
                var out = new PrintWriter(socket.getOutputStream(), true);
                var in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                String empre = in.readLine();
                f=f+1;  
                out.println(empre+f);
             } catch (Exception e) {
                System.out.println("Error en run:" + socket);
            } finally {
                try {
                    socket.close();
                } catch (IOException e) {
                }
                System.out.println("Closed: " + socket);
            }
        }
    }

}