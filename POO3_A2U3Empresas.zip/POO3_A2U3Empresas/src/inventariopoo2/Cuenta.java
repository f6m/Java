/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package inventariopoo2;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.FormatterClosedException;
import java.util.NoSuchElementException;
import java.util.Scanner;

/**
 *
 * @author lunas
 */
public class Cuenta {
	public int balance;
	public int Nocta;
        
        //
	void muestraBalance() {
		System.out.println("Balance: No. cuenta: " + Nocta + " Cantidad: " + balance);
	}

	   synchronized void deposito(int cantidad){
                        if(cantidad > 0)
                        {
			balance = balance + cantidad;
			System.out.println(cantidad + " es depositada");
			muestraBalance();
                        }
                        else {
                           System.out.println("Operacion inválida: Cantidad negativa a depositar " + cantidad);
                           return; 
                        }
	   }

	   synchronized void retiro(int cantidad){
                          if(balance >= cantidad)
                          {
                              balance = balance - cantidad;
                              System.out.println( cantidad + " es retirada");
                              muestraBalance();
                          }
                          else {
                              System.out.println("Operacion invál   ida: La cantidad a retirar es mayor que " + cantidad);
                              return;
                          }                          
	   }
}

class TransaccionDeposito implements Runnable{
	int cantidad;
	Cuenta cuentaX;
        
        //Constructor para el hilo deposito con dos parameteros: un objeto Cuenta y un entero
	TransaccionDeposito(Cuenta x, int cantidad){
		cuentaX = x;
		this.cantidad = cantidad;
		new Thread(this).start();
	}
	//Este es el metodo que se ejecuta en paralelo virtualmente compartiendo los recursos
	public void run(){
		cuentaX.deposito(cantidad);
                try{
                File file = new File("/Users/lunas/Documents/NetBeansProjects/InventarioPOO3_EAU2/cuentas.txt");
                Scanner sc = new Scanner(file);
                StringBuffer buffer = new StringBuffer();
                while (sc.hasNextLine()) {
                    buffer.append(sc.nextLine()+System.lineSeparator());
                    }
                String fileContents = buffer.toString(); //Convierte el archivo a cadena
                System.out.println("Contenido en CADENA del archivo: "+fileContents);
                sc.close(); //Cerramos el objeto escaner
                String lineao = Integer.toString(cuentaX.Nocta)+" "+Integer.toString(cuentaX.balance-cantidad);
                System.out.println("LINEA ANTES: "+lineao);
                String linean = Integer.toString(cuentaX.Nocta)+" "+Integer.toString(cuentaX.balance);
                System.out.println("LINEA NUEVA: "+linean);
                fileContents = fileContents.replaceAll(lineao, linean); //Remplazamos la antigua linea con la nueva
                FileWriter escribir = new FileWriter(file); //FileWriter(file,true) es para abrirlo en modo append
                System.out.println("Nuevo archivo CON LINEA NUEVA: "+fileContents);
                escribir.append(fileContents);
                escribir.flush();
                escribir.close();
                }
                catch (FormatterClosedException fce){
                 System.err.println("Error al escribir el archivo. Fin");
                }
                catch (NoSuchElementException eEx){
                 System.err.println("Entrada invalida. Intenta de nuevo");
                 }   
                catch (IOException ex) {   
                java.util.logging.Logger.getLogger(AvaluoLoteAltas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
                 }
               }
    }
// implements Runnable significa
class TransaccionRetiro implements Runnable{
	int cantidad;
	Cuenta cuentaY;
	
        //Constructor para el hilo deposito con dos parameteros: un objeto Cuenta y un entero
	TransaccionRetiro(Cuenta y, int cantidad) {
		cuentaY = y;
		this.cantidad = cantidad;
		new Thread(this).start();
	}
	
	public void run(){
		cuentaY.retiro(cantidad);
	}
}
