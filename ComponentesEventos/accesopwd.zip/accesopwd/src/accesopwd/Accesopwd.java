/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package accesopwd;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 *
 * @author usuario
 */
public class Accesopwd extends Application { //Application es una clase abstracta
  //arreglo doble de 3x2
  private final String[][] users = {{"admin","root","true"},{"user","usuario","false"}};
  //private Stage stage; //objeto Stage

     public static void main(String[] args) {
        // TODO code application logic here
       Application.launch(args);
     }
     
  @Override
  public void start(final Stage stage) {
    //stage = stage;
    stage.setTitle("Control de acceso - Login");
    stage.getIcons().add(new Image("file:resources/unadm.jpg"));
    stage.setResizable(false);
    stage.setScene(this.login());
    stage.getScene().getStylesheets().add("file:resources/webcss.css");
    stage.centerOnScreen();
    stage.show();
  }
  
  /**
   * Crea la escena para la autentificación en el sistema.
   * @return Escena.
   */
  public Scene login() {    
    GridPane grid = new GridPane(); //un objeto contenedor grid
    grid.getStyleClass().add("background");
    grid.setAlignment(Pos.CENTER);
    grid.setHgap(10); //espacio horizontal en pixeles en los nodos del grid
    grid.setVgap(10); //espacio horizontal en pixeles en los nodos del grid
    grid.setPadding(new Insets(15,15,15,15)); //margenes alrededor del grid (arriba, abajo, izq, der)
    
    Label usuario = new Label("Usuario:");
    grid.add(usuario, 0, 0);

    TextField userTF = new TextField();
    grid.add(userTF, 1, 0);

    Label pw = new Label("Contrase\u00F1a:");
    grid.add(pw, 0, 1);

    PasswordField pwPF = new PasswordField();
    grid.add(pwPF, 1, 1);
    
    Button btn = new Button("Iniciar sesi\u00F3n");
    grid.add(btn, 1, 2);
    
    Text txt = new Text("Inicie sesi\u00F3n para continuar");
    txt.setFill(Color.GREEN);
    grid.add(txt, 1, 3);
     //Accion del boton btn del grid en (1,2)
    btn.setOnAction((ActionEvent) -> { //metodo setOnAction del boton, 
      if(!"".equals(userTF.getText())) { //si no es vacio el nombre de usuario
        if(!"".equals(pwPF.getText())) { //si no es vacio el pwd
          for (String[] user : users) { // para los usuarios en el arreglo users
            if(user[0].equals(userTF.getText())) {
              if(user[1].equals(pwPF.getText())) { //usar un hash pero solo comparamos
                txt.setText("Cargando...");
                //stage.setUserData(user[2]); //set stage 
                Platform.runLater(() -> {
                txt.setText("Acceso permitido...");});
                txt.setFill(Color.RED);
                //Platform.exit(); 
                return;
              }
            }
          }
          userTF.clear();
          pwPF.clear();
          txt.setText("Usuaio/Contrase\u00F1a invalido");
        } else {
          txt.setText("Introduce una contrase\u00F1a");
        }
      } else {
        txt.setText("Introduce un usuario");
      }
      txt.setFill(Color.FIREBRICK);
    });
    
    return new Scene(grid, 300, 150); //devuelve el objeto scene instanciado
  } //Fin de login

          
} //fin de Accesopwd
