/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package inventariopoo2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Main {

    /**
     * @author Vicente Eduardo Pérez Carreño
     * Matrícula: ES172009000
     * Grupo: DS-DPO2-2201-B1-002
     * @param args the command line arguments
     */ 
    public static void main(String[] args) {
        /*
        * Se instancia el MainFrame desde la clase Main
        */
        MainFrame mainFrame = new MainFrame();
        mainFrame.setVisible(true);


    }
    
}




        /*   CUADROS DE DIALOGO
        //showInputDialog (la respuesta es String si es campo de texto)
        String textoVentana =JOptionPane.showInputDialog(null, "Ejemplo de ventana InputDialog",
                "UNADM DPO2_U2_A3_VIPC", JOptionPane.INFORMATION_MESSAGE);
        
        /* Tipo de mensajes en JDialog 
            JOptionPane.WARNING_MESSAGE
            JOptionPane.ERROR_MESSAGE
            JOptionPane.PLAIN_MESSAGE
            JOptionPane.INFORMATION_MESSAGE
            JOptionPane.QUESTION_MESSAGE
        */
        
        /* Botones predeterminados en JDialog (La respuesta se obtiene un número entero a partir del 0 como la primer opcion)
            JOptionPane.YES_NO_CANCEL_OPTION
            JOptionPane.DEFAULT_OPTION
            JOptionPane.YES_NO_OPTION
            JOptionPane.OK_CANCEL_OPTION
        */
        /*
        //showMessageDialog
        JOptionPane.showMessageDialog(null, "Cuadro de dialogo MessageDialog","UNADM DPO2_U2_A3_VIPC", JOptionPane.WARNING_MESSAGE);
        
        
        //showConfirmDialog
        int y = JOptionPane.showConfirmDialog(null, "Cuadro de dialogo ConfirmDialog",
        "UNADM DPO2_U2_A3_VIPC", JOptionPane.YES_NO_OPTION,
        JOptionPane.INFORMATION_MESSAGE);
        
        System.out.println("la opcion fue " + y);

        ImageIcon icon = new ImageIcon("C:/Users/reave/Documents/NetBeansProjects/InventarioPOO2/src/inventariopoo2/icons/producto.png");
        
        String[] optiones = {"Opción 1", "Opción 2", "Opción 3", "Opción 4"};
        //showOptionDialog
        int x = JOptionPane.showOptionDialog(null, "Cuadro de dialogo OptionDialog con 4 opciones",
                "UNADM DPO2_U2_A3_VIPC", JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, icon, optiones, optiones[0]);
        
        System.out.println("la opcion fue " + x);
        */